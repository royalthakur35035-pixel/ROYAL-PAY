package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class SpinSector(
    val amount: Int,
    val label: String,
    val color: Color,
    val textColor: Color = Color.White
)

@Composable
fun LuckySpinDialog(
    onDismiss: () -> Unit,
    onClaimReward: (Int) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isSpinning by remember { mutableStateOf(false) }
    var winningSector by remember { mutableStateOf<SpinSector?>(null) }
    var showWinningState by remember { mutableStateOf(false) }

    val rotation = remember { Animatable(0f) }

    val sectors = remember {
        listOf(
            SpinSector(100, "₹100", Color(0xFFD4AF37), Color(0xFF121212)),
            SpinSector(50, "₹50", Color(0xFF1A1A1A), Color(0xFFD4AF37)),
            SpinSector(200, "₹200", Color(0xFF00E676), Color(0xFF121212)),
            SpinSector(70, "₹70", Color(0xFF2C2C2C), Color.White),
            SpinSector(500, "₹500", Color(0xFFE53935), Color.White),
            SpinSector(150, "₹150", Color(0xFF7C4DFF), Color.White)
        )
    }

    Dialog(onDismissRequest = { if (!isSpinning) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkSurface,
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, GoldPrimary, RoundedCornerShape(24.dp))
                .testTag("lucky_spin_dialog")
        ) {
            Box(modifier = Modifier.padding(20.dp)) {
                // Close button
                if (!isSpinning) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(28.dp)
                            .testTag("close_lucky_spin_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close",
                            tint = TextSecondary
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Header Tag
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GoldPrimary.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Stars,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "1ST ORDER EXCLUSIVE BONUS",
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "🎰 First Order Lucky Spin",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "Spin the wheel to win instant cash bonus on your 1st order!",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    // WHEEL CONTAINER
                    Box(
                        modifier = Modifier
                            .size(260.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Outer Golden Ring Glow
                        Box(
                            modifier = Modifier
                                .size(256.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(GoldPrimary.copy(alpha = 0.3f), Color.Transparent)
                                    )
                                )
                                .border(4.dp, GoldPrimary, CircleShape)
                        )

                        // Rotating Canvas Wheel
                        Canvas(
                            modifier = Modifier
                                .size(240.dp)
                                .rotate(rotation.value)
                        ) {
                            val canvasWidth = size.width
                            val canvasHeight = size.height
                            val radius = canvasWidth / 2f
                            val center = Offset(radius, radius)
                            val sectorAngle = 360f / sectors.size

                            sectors.forEachIndexed { index, sector ->
                                val startAngle = index * sectorAngle - 90f
                                drawArc(
                                    color = sector.color,
                                    startAngle = startAngle,
                                    sweepAngle = sectorAngle,
                                    useCenter = true,
                                    size = Size(canvasWidth, canvasHeight)
                                )

                                drawArc(
                                    color = GoldPrimary.copy(alpha = 0.5f),
                                    startAngle = startAngle,
                                    sweepAngle = sectorAngle,
                                    useCenter = true,
                                    style = Stroke(width = 2f),
                                    size = Size(canvasWidth, canvasHeight)
                                )
                            }
                        }

                        // Static Pointer Indicator at top
                        Canvas(
                            modifier = Modifier
                                .size(32.dp)
                                .align(Alignment.TopCenter)
                                .offset(y = (-6).dp)
                        ) {
                            val path = Path().apply {
                                moveTo(size.width / 2f, size.height)
                                lineTo(0f, 0f)
                                lineTo(size.width, 0f)
                                close()
                            }
                            drawPath(path, color = GoldPrimary)
                            drawPath(path, color = Color.White, style = Stroke(width = 2f))
                        }

                        // Center Spin Button
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(GoldPrimary, Color(0xFFB38F28))
                                    )
                                )
                                .border(3.dp, Color.White, CircleShape)
                                .clickable(enabled = !isSpinning && !showWinningState) {
                                    isSpinning = true
                                    coroutineScope.launch {
                                        // Pick a winning sector (e.g., sector 0: ₹100 or sector 2: ₹200)
                                        val winIndex = 0 // ₹100 guaranteed win!
                                        val sectorAngle = 360f / sectors.size
                                        // Sector 0 spans from -90 to -90 + 60 = -30 deg
                                        // Pointer is at Top (0 deg offset from top)
                                        val targetSectorCenter = winIndex * sectorAngle + (sectorAngle / 2f)
                                        val targetAngle = 360f * 6 + (360f - targetSectorCenter)

                                        rotation.animateTo(
                                            targetValue = targetAngle,
                                            animationSpec = tween(
                                                durationMillis = 3500,
                                                easing = FastOutSlowInEasing
                                            )
                                        )

                                        isSpinning = false
                                        winningSector = sectors[winIndex]
                                        showWinningState = true
                                    }
                                }
                                .testTag("start_spin_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isSpinning) "SPINNING" else "SPIN 🎰",
                                color = Color(0xFF121212),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // WINNING OVERLAY / ACTION BUTTON
                    if (showWinningState && winningSector != null) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = GreenAccent.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GreenAccent),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "🎉 CONGRATULATIONS!",
                                    color = GreenAccent,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "You won ₹${winningSector!!.amount} Cash Bonus on your 1st Order!",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                RoyalButton(
                                    text = "CLAIM ₹${winningSector!!.amount} & BUY ORDER 🚀",
                                    onClick = {
                                        onClaimReward(winningSector!!.amount)
                                    },
                                    testTag = "claim_spin_reward_btn"
                                )
                            }
                        }
                    } else {
                        RoyalButton(
                            text = if (isSpinning) "SPINNING WHEEL..." else "TAP SPIN TO WIN 🎰",
                            enabled = !isSpinning,
                            onClick = {
                                if (!isSpinning) {
                                    isSpinning = true
                                    coroutineScope.launch {
                                        val winIndex = 0 // ₹100 guaranteed bonus!
                                        val sectorAngle = 360f / sectors.size
                                        val targetSectorCenter = winIndex * sectorAngle + (sectorAngle / 2f)
                                        val targetAngle = 360f * 6 + (360f - targetSectorCenter)

                                        rotation.animateTo(
                                            targetValue = targetAngle,
                                            animationSpec = tween(
                                                durationMillis = 3500,
                                                easing = FastOutSlowInEasing
                                            )
                                        )

                                        isSpinning = false
                                        winningSector = sectors[winIndex]
                                        showWinningState = true
                                    }
                                }
                            },
                            testTag = "tap_spin_main_btn"
                                )
                    }
                }
            }
        }
    }
}
