package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object Home : Screen("home")
    object Buy : Screen("buy")
    object Sell : Screen("sell")
    object Wallet : Screen("wallet")
    object Withdraw : Screen("withdraw")
    object History : Screen("history")
    object Team : Screen("team")
    object Vip : Screen("vip")
    object Notifications : Screen("notifications")
    object Support : Screen("support")
    object Profile : Screen("profile")
    object AdminPanel : Screen("admin_panel")
}
