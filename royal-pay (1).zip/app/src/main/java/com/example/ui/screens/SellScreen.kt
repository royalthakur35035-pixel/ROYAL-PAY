package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalButton
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalTextField
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SellScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val userState by viewModel.user.collectAsState()
    val user = userState

    var sellAmount by remember { mutableStateOf("") }
    var upiId by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitted by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "SELL BALANCE",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "buy", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // WALLET INFO CARD
            RoyalCard(borderGold = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Available Wallet Balance", color = TextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹${String.format("%.2f", user?.walletBalance ?: 0.0)}",
                            color = GoldPrimary,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.AccountBalanceWallet,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SELL ORDER FORM
            RoyalCard(borderGold = true) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "SELL ORDER DETAILS",
                        color = GoldPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    RoyalTextField(
                        value = sellAmount,
                        onValueChange = { sellAmount = it },
                        label = "Amount to Sell (₹)",
                        leadingIcon = Icons.Filled.CurrencyRupee,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        testTag = "sell_amount_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    RoyalTextField(
                        value = upiId,
                        onValueChange = { upiId = it },
                        label = "Your UPI ID (e.g. mobile@upi)",
                        leadingIcon = Icons.Filled.Payment,
                        testTag = "sell_upi_input"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "• Funds will be sent directly to your UPI ID upon Admin approval.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    errorMessage?.let { err ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = err, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    RoyalButton(
                        text = if (isSubmitted) "ORDER SUBMITTED" else "SUBMIT SELL ORDER",
                        enabled = !isSubmitted,
                        onClick = {
                            val amt = sellAmount.toDoubleOrNull()
                            if (amt == null || amt <= 0) {
                                errorMessage = "Enter a valid sell amount"
                            } else if ((user?.walletBalance ?: 0.0) < amt) {
                                errorMessage = "Insufficient balance in your wallet!"
                            } else if (upiId.isBlank() || !upiId.contains("@")) {
                                errorMessage = "Enter a valid UPI ID"
                            } else {
                                errorMessage = null
                                isSubmitted = true
                                viewModel.submitSell(
                                    amount = amt,
                                    upiId = upiId,
                                    onSuccess = {
                                        sellAmount = ""
                                        upiId = ""
                                        isSubmitted = false
                                        onNavigate("history")
                                    }
                                )
                            }
                        },
                        testTag = "sell_submit_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
