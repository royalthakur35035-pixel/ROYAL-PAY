package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionRecord
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionType
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.*

@Composable
fun TransactionHistoryScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val transactionsState by viewModel.transactions.collectAsState()
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filters = listOf("ALL", "DEPOSIT", "WITHDRAWAL", "BUY", "SELL")

    val filteredList = remember(transactionsState, selectedFilter) {
        if (selectedFilter == "ALL") transactionsState
        else transactionsState.filter { it.type.name.equals(selectedFilter, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "TRANSACTION HISTORY",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "history", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // FILTER CHIPS & CLEAR HISTORY BUTTON
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filters) { filter ->
                        val isSelected = selectedFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFilter = filter },
                            label = {
                                Text(
                                    text = filter,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) androidx.compose.ui.graphics.Color.Black else GoldPrimary
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldPrimary,
                                containerColor = DarkSurface
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = GoldPrimary
                            ),
                            modifier = Modifier.testTag("filter_chip_$filter")
                        )
                    }
                }

                if (transactionsState.isNotEmpty()) {
                    TextButton(
                        onClick = { viewModel.clearHistory() },
                        modifier = Modifier.testTag("clear_history_btn")
                    ) {
                        Text(
                            text = "Clear All",
                            color = RedAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No $selectedFilter transactions found",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredList) { txn ->
                        DetailedTransactionCard(txn = txn)
                    }
                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun DetailedTransactionCard(txn: TransactionRecord) {
    RoyalCard(borderGold = true) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = when (txn.status) {
                            TransactionStatus.Approved -> GreenAccent.copy(alpha = 0.2f)
                            TransactionStatus.Pending -> GoldPrimary.copy(alpha = 0.2f)
                            TransactionStatus.Rejected -> RedAccent.copy(alpha = 0.2f)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = txn.type.name.take(1),
                                color = when (txn.status) {
                                    TransactionStatus.Approved -> GreenAccent
                                    TransactionStatus.Pending -> GoldPrimary
                                    TransactionStatus.Rejected -> RedAccent
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "${txn.type.name} ORDER",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Ref ID: #${txn.id}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Text(
                    text = "₹${String.format("%.2f", txn.amount)}",
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = DarkBorder)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Date & Time:", color = TextSecondary, fontSize = 12.sp)
                Text(text = "${txn.date} at ${txn.time}", color = TextPrimary, fontSize = 12.sp)
            }

            if (txn.utr.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "UTR / Ref:", color = TextSecondary, fontSize = 12.sp)
                    Text(text = txn.utr, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }

            if (txn.upiId.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "UPI ID:", color = TextSecondary, fontSize = 12.sp)
                    Text(text = txn.upiId, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Status:", color = TextSecondary, fontSize = 12.sp)
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = when (txn.status) {
                        TransactionStatus.Approved -> GreenAccent.copy(alpha = 0.2f)
                        TransactionStatus.Pending -> GoldPrimary.copy(alpha = 0.2f)
                        TransactionStatus.Rejected -> RedAccent.copy(alpha = 0.2f)
                    }
                ) {
                    Text(
                        text = txn.status.name.uppercase(),
                        color = when (txn.status) {
                            TransactionStatus.Approved -> GreenAccent
                            TransactionStatus.Pending -> GoldPrimary
                            TransactionStatus.Rejected -> RedAccent
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
