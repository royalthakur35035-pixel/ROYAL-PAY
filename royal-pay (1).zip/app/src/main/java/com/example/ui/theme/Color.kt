package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4AF37)
val GoldVariant = Color(0xFFB8860B)
val GoldAccent = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF9E29C)

val DarkBackground = Color(0xFF0A0A0A)
val DarkSurface = Color(0xFF1A1A1A)
val DarkSurfaceVariant = Color(0xFF26262A)
val DarkSurfaceCard = Color(0xFF121214)
val DarkBorder = Color(0x33D4AF37)
val DarkBorderLight = Color(0x1AFFFFFF)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9CA3AF)

val RedAccent = Color(0xFFEF4444)
val GreenAccent = Color(0xFF4CAF50)


