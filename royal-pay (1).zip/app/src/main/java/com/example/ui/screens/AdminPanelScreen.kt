package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionRecord
import com.example.data.model.TransactionStatus
import com.example.data.model.User
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalButton
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalStatCard
import com.example.ui.components.RoyalTextField
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val allUsersState by viewModel.allUsers.collectAsState()
    val transactionsState by viewModel.transactions.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Dashboard, 1: Pending Transactions, 2: Users, 3: Broadcast
    var broadcastTitle by remember { mutableStateOf("") }
    var broadcastMessage by remember { mutableStateOf("") }
    var userToEditWallet by remember { mutableStateOf<User?>(null) }
    var newWalletBalanceInput by remember { mutableStateOf("") }
    var snackbarMsg by remember { mutableStateOf<String?>(null) }

    val pendingTxns = remember(transactionsState) {
        transactionsState.filter { it.status == TransactionStatus.Pending }
    }

    val totalDepositsSum = remember(transactionsState) {
        transactionsState.filter { (it.type == com.example.data.model.TransactionType.DEPOSIT || it.type == com.example.data.model.TransactionType.BUY) && it.status == TransactionStatus.Approved }.sumOf { it.amount }
    }

    val totalWithdrawalsSum = remember(transactionsState) {
        transactionsState.filter { (it.type == com.example.data.model.TransactionType.WITHDRAWAL || it.type == com.example.data.model.TransactionType.SELL) && it.status == TransactionStatus.Approved }.sumOf { it.amount }
    }

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "ROYAL ADMIN PANEL",
                showBack = true,
                onBackClick = onNavigateBack
            )
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // TAB SELECTOR
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = GoldPrimary,
                edgePadding = 0.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Dashboard", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Approvals (${pendingTxns.size})",
                            fontWeight = FontWeight.Bold,
                            color = if (pendingTxns.isNotEmpty()) GoldPrimary else TextSecondary
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Users", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Broadcast", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (selectedTab) {
                0 -> {
                    // DASHBOARD OVERVIEW
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Text(
                                text = "ADMIN PLATFORM METRICS",
                                color = GoldPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                RoyalStatCard(
                                    title = "Total Registered Users",
                                    amount = "${allUsersState.size}",
                                    icon = Icons.Filled.Group,
                                    accentColor = GoldPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                                RoyalStatCard(
                                    title = "Pending Approvals",
                                    amount = "${pendingTxns.size}",
                                    icon = Icons.Filled.HourglassTop,
                                    accentColor = RedAccent,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                RoyalStatCard(
                                    title = "Total Approved Deposits",
                                    amount = "₹${String.format("%.2f", totalDepositsSum)}",
                                    icon = Icons.Filled.AddCard,
                                    accentColor = GreenAccent,
                                    modifier = Modifier.weight(1f)
                                )
                                RoyalStatCard(
                                    title = "Total Approved Withdrawals",
                                    amount = "₹${String.format("%.2f", totalWithdrawalsSum)}",
                                    icon = Icons.Filled.AccountBalance,
                                    accentColor = GoldVariant,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        item {
                            RoyalStatCard(
                                title = "Platform Total Revenue",
                                amount = "₹${String.format("%.2f", (totalDepositsSum - totalWithdrawalsSum).coerceAtLeast(0.0))}",
                                icon = Icons.Filled.MonetizationOn,
                                accentColor = GoldPrimary
                            )
                        }
                    }
                }

                1 -> {
                    // PENDING APPROVALS LIST
                    if (pendingTxns.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "No pending deposit/withdrawal requests", color = TextSecondary, fontSize = 14.sp)
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(pendingTxns) { txn ->
                                AdminTransactionApprovalCard(
                                    txn = txn,
                                    onApprove = {
                                        viewModel.approveTransaction(txn.id)
                                        snackbarMsg = "Approved transaction #${txn.id}"
                                    },
                                    onReject = {
                                        viewModel.rejectTransaction(txn.id)
                                        snackbarMsg = "Rejected transaction #${txn.id}"
                                    }
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // USER MANAGEMENT
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(allUsersState) { usr ->
                            AdminUserCard(
                                user = usr,
                                onToggleBlock = {
                                    viewModel.toggleBlockUser(usr.uid)
                                    snackbarMsg = "Toggled block status for ${usr.name}"
                                },
                                onEditWallet = {
                                    userToEditWallet = usr
                                    newWalletBalanceInput = usr.walletBalance.toString()
                                }
                            )
                        }
                    }
                }

                3 -> {
                    // BROADCAST NOTIFICATIONS
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            RoyalCard(borderGold = true) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "SEND BROADCAST ANNOUNCEMENT",
                                        color = GoldPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    RoyalTextField(
                                        value = broadcastTitle,
                                        onValueChange = { broadcastTitle = it },
                                        label = "Notification Title",
                                        leadingIcon = Icons.Filled.Title
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    RoyalTextField(
                                        value = broadcastMessage,
                                        onValueChange = { broadcastMessage = it },
                                        label = "Announcement Message",
                                        leadingIcon = Icons.Filled.Message,
                                        singleLine = false
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    RoyalButton(
                                        text = "BROADCAST TO ALL USERS",
                                        onClick = {
                                            if (broadcastTitle.isNotBlank() && broadcastMessage.isNotBlank()) {
                                                viewModel.sendBroadcastNotification(broadcastTitle, broadcastMessage)
                                                broadcastTitle = ""
                                                broadcastMessage = ""
                                                snackbarMsg = "Broadcast message sent to all users!"
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    userToEditWallet?.let { usr ->
        AlertDialog(
            onDismissRequest = { userToEditWallet = null },
            title = { Text(text = "Edit Wallet Balance: ${usr.name}", color = GoldPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    RoyalTextField(
                        value = newWalletBalanceInput,
                        onValueChange = { newWalletBalanceInput = it },
                        label = "New Balance (₹)",
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val newBal = newWalletBalanceInput.toDoubleOrNull()
                        if (newBal != null) {
                            viewModel.updateWalletBalanceAdmin(usr.uid, newBal)
                            snackbarMsg = "Wallet balance updated for ${usr.name}"
                        }
                        userToEditWallet = null
                    }
                ) {
                    Text(text = "Save Balance", color = GoldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { userToEditWallet = null }) {
                    Text(text = "Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkBackground
        )
    }

    snackbarMsg?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(2500)
            snackbarMsg = null
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Snackbar(
                containerColor = GoldPrimary,
                contentColor = androidx.compose.ui.graphics.Color.Black
            ) {
                Text(text = msg, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AdminTransactionApprovalCard(
    txn: TransactionRecord,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    RoyalCard(borderGold = true) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${txn.type.name} - ₹${String.format("%.2f", txn.amount)}",
                    color = GoldPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(text = txn.date, color = TextSecondary, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(text = "User: ${txn.userName} (${txn.userEmail})", color = TextPrimary, fontSize = 13.sp)
            if (txn.utr.isNotBlank()) {
                Text(text = "UTR: ${txn.utr}", color = GoldVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            if (txn.upiId.isNotBlank()) {
                Text(text = "UPI: ${txn.upiId}", color = GoldVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = GreenAccent, contentColor = androidx.compose.ui.graphics.Color.Black),
                    modifier = Modifier.weight(1f).testTag("admin_approve_${txn.id}")
                ) {
                    Text(text = "APPROVE", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onReject,
                    colors = ButtonDefaults.buttonColors(containerColor = RedAccent, contentColor = androidx.compose.ui.graphics.Color.White),
                    modifier = Modifier.weight(1f).testTag("admin_reject_${txn.id}")
                ) {
                    Text(text = "REJECT", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AdminUserCard(
    user: User,
    onToggleBlock: () -> Unit,
    onEditWallet: () -> Unit
) {
    RoyalCard(borderGold = false) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = user.name, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(text = "${user.email} • ${user.mobile}", color = TextSecondary, fontSize = 11.sp)
                }
                Text(
                    text = "₹${String.format("%.2f", user.walletBalance)}",
                    color = GoldPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onEditWallet,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = "Edit Wallet", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onToggleBlock,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (user.isBlocked) GreenAccent else RedAccent
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (user.isBlocked) "Unblock User" else "Block User",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
