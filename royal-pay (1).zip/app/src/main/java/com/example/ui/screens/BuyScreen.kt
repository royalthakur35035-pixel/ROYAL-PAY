package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.components.LuckySpinDialog
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalButton
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalTextField
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.*

@Composable
fun BuyScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    var rechargeAmount by remember { mutableStateOf("300") }
    var utrNumber by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitted by remember { mutableStateOf(false) }
    var showPaymentQrDialog by remember { mutableStateOf(false) }
    var showLuckySpinDialog by remember { mutableStateOf(false) }
    var hasSpunLuckySpin by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "BUY & RECHARGE",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "buy", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1ST ORDER LUCKY SPIN BANNER
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DarkSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, GoldPrimary, RoundedCornerShape(16.dp))
                    .clickable { showLuckySpinDialog = true }
                    .testTag("lucky_spin_banner")
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "🎰 1st Order Lucky Spin", color = GoldPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Spin the wheel & win up to ₹500 instant cash bonus!", color = TextSecondary, fontSize = 11.sp)
                    }
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = GoldPrimary
                    ) {
                        Text(
                            text = if (hasSpunLuckySpin) "SPUN ✓" else "SPIN 🎰",
                            color = Color(0xFF121212),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // SELECT ORDER BUY PACKAGE CARD
            RoyalCard(borderGold = true) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SELECT ORDER BUY PACKAGE",
                            color = GoldPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GreenAccent.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "⚡ Fast Withdrawal",
                                color = GreenAccent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Bonus offer line
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = "🎁 1st Order Complete: ₹260 Bonus | 5 Orders Complete: ₹1000 Bonus",
                            color = GoldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val packageAmounts = listOf(300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500)
                    val orderPackages = packageAmounts.map { amt ->
                        Triple(amt, 14, (amt * 1.14).toInt())
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        orderPackages.chunked(2).forEach { rowPkgs ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                rowPkgs.forEach { (amount, profitPercent, totalReturn) ->
                                    val isSelected = rechargeAmount == amount.toString()
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) GoldPrimary.copy(alpha = 0.15f) else DarkSurface
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) GoldPrimary else DarkSurface,
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .clickable {
                                                rechargeAmount = amount.toString()
                                                errorMessage = null
                                                if (!hasSpunLuckySpin) {
                                                    showLuckySpinDialog = true
                                                } else {
                                                    showPaymentQrDialog = true
                                                }
                                            }
                                            .testTag("package_$amount")
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            horizontalAlignment = Alignment.Start
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "Order Buy",
                                                    color = GoldPrimary,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = GoldPrimary.copy(alpha = 0.2f)
                                                ) {
                                                    Text(
                                                        text = "$profitPercent%",
                                                        color = GoldPrimary,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))

                                            Text(
                                                text = "₹$amount",
                                                color = TextPrimary,
                                                fontSize = 20.sp,
                                                fontWeight = FontWeight.Bold
                                            )

                                            Spacer(modifier = Modifier.height(4.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "Return: ₹$totalReturn",
                                                    color = GreenAccent,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = GreenAccent.copy(alpha = 0.2f)
                                                ) {
                                                    Text(
                                                        text = "BUY ⚡",
                                                        color = GreenAccent,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // RECHARGE INPUT CARD
            RoyalCard(borderGold = true) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "CUSTOM ORDER AMOUNT",
                        color = GoldPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    RoyalTextField(
                        value = rechargeAmount,
                        onValueChange = {
                            rechargeAmount = it
                            errorMessage = null
                        },
                        label = "Recharge Amount (₹)",
                        leadingIcon = Icons.Filled.CurrencyRupee,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        testTag = "buy_amount_input"
                    )

                    errorMessage?.let { err ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = err, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    RoyalButton(
                        text = "PROCEED TO BUY & PAY ${if (rechargeAmount.isNotBlank()) "₹$rechargeAmount" else ""}",
                        enabled = !isSubmitted,
                        onClick = {
                            val amt = rechargeAmount.toDoubleOrNull()
                            if (amt == null || amt < 300) {
                                errorMessage = "Minimum order buy amount is ₹300"
                            } else {
                                errorMessage = null
                                if (!hasSpunLuckySpin) {
                                    showLuckySpinDialog = true
                                } else {
                                    showPaymentQrDialog = true
                                }
                            }
                        },
                        testTag = "proceed_to_buy_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // 1ST ORDER LUCKY SPIN DIALOG
        if (showLuckySpinDialog) {
            LuckySpinDialog(
                onDismiss = {
                    showLuckySpinDialog = false
                    showPaymentQrDialog = true
                },
                onClaimReward = { rewardAmount ->
                    viewModel.claimLuckySpinReward(rewardAmount.toDouble())
                    hasSpunLuckySpin = true
                    showLuckySpinDialog = false
                    showPaymentQrDialog = true
                }
            )
        }

        // PAYMENT QR DIALOG WHEN ORDER IS BOUGHT
        if (showPaymentQrDialog) {
            Dialog(onDismissRequest = { showPaymentQrDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.QrCodeScanner,
                                    contentDescription = "QR Code",
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "SCAN QR TO PAY ₹$rechargeAmount",
                                    color = GoldPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(
                                onClick = { showPaymentQrDialog = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "Close",
                                    tint = TextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // QR CODE DISPLAY
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(280.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.payment_qr_code),
                                contentDescription = "Payment QR Code",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // ACCOUNT HOLDER NAME & UPI ID DETAILS
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // UPI ID CARD
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = DarkBackground,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(text = "Official UPI ID", color = TextSecondary, fontSize = 11.sp)
                                        Text(text = "neha.singh80@fam", color = GoldPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = "Copy UPI ID",
                                        tint = GoldPrimary,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clickable {
                                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                val clip = android.content.ClipData.newPlainText("UPI ID", "neha.singh80@fam")
                                                clipboard.setPrimaryClip(clip)
                                            }
                                    )
                                }
                            }

                            // ACCOUNT HOLDER NAME CARD
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = DarkBackground,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(text = "Account Holder Name", color = TextSecondary, fontSize = 11.sp)
                                        Text(text = "Vikal Singh", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = "Copy Name",
                                        tint = GoldPrimary,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clickable {
                                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                val clip = android.content.ClipData.newPlainText("Account Name", "Vikal Singh")
                                                clipboard.setPrimaryClip(clip)
                                            }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        RoyalTextField(
                            value = utrNumber,
                            onValueChange = {
                                utrNumber = it
                                errorMessage = null
                            },
                            label = "Enter 12-Digit UTR / Ref No.",
                            leadingIcon = Icons.Filled.Numbers,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            testTag = "dialog_utr_input"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // SCREENSHOT UPLOAD BOX
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkBackground)
                                .border(
                                    width = 1.dp,
                                    color = if (selectedImageUri != null) GoldPrimary else GoldPrimary.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { imagePickerLauncher.launch("image/*") }
                                .testTag("dialog_upload_screenshot_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Filled.CloudUpload,
                                    contentDescription = "Upload Screenshot",
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (selectedImageUri != null) "Screenshot Attached ✓" else "Tap to Upload Payment Screenshot",
                                    color = if (selectedImageUri != null) GoldPrimary else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        errorMessage?.let { err ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = err, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        RoyalButton(
                            text = if (isSubmitted) "SUBMITTING..." else "SUBMIT PAYMENT",
                            enabled = !isSubmitted,
                            onClick = {
                                val amt = rechargeAmount.toDoubleOrNull()
                                if (amt == null || amt < 300) {
                                    errorMessage = "Minimum order buy amount is ₹300"
                                } else if (utrNumber.length < 8) {
                                    errorMessage = "Enter a valid 12-digit UTR number"
                                } else {
                                    errorMessage = null
                                    isSubmitted = true
                                    viewModel.submitBuyPayment(
                                        amount = amt,
                                        utr = utrNumber,
                                        screenshotUri = selectedImageUri?.toString() ?: "qr_screenshot_uploaded.png",
                                        onSuccess = {
                                            rechargeAmount = ""
                                            utrNumber = ""
                                            selectedImageUri = null
                                            isSubmitted = false
                                            showPaymentQrDialog = false
                                            onNavigate("history")
                                        }
                                    )
                                }
                            },
                            testTag = "dialog_submit_payment_button"
                        )
                    }
                }
            }
        }
    }
}

