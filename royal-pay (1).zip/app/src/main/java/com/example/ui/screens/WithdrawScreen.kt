package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalButton
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalTextField
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.*
import com.example.ui.theme.TextSecondary

@Composable
fun WithdrawScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val userState by viewModel.user.collectAsState()
    val user = userState

    var withdrawAmount by remember { mutableStateOf("") }
    var upiId by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitted by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "WITHDRAW FUNDS",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "wallet", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // BALANCE DISPLAY CARD
            RoyalCard(borderGold = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Withdrawable Wallet Balance", color = TextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "₹${String.format("%.2f", user?.walletBalance ?: 190.0)}",
                            color = GoldPrimary,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.AccountBalanceWallet,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // FAST WITHDRAWAL ACTIVE BANNER
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = GreenAccent.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, GreenAccent)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "⚡", fontSize = 16.sp)
                        Column {
                            Text(
                                text = "FAST WITHDRAWAL ACTIVE",
                                color = GreenAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "24/7 Instant UPI Transfer Guarantee",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // WITHDRAW FORM CARD
            RoyalCard(borderGold = true) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "WITHDRAWAL DETAILS",
                        color = GoldPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    RoyalTextField(
                        value = withdrawAmount,
                        onValueChange = { withdrawAmount = it },
                        label = "Withdrawal Amount (Min ₹200)",
                        leadingIcon = Icons.Filled.CurrencyRupee,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        testTag = "withdraw_amount_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    RoyalTextField(
                        value = upiId,
                        onValueChange = { upiId = it },
                        label = "UPI ID",
                        leadingIcon = Icons.Filled.Payment,
                        testTag = "withdraw_upi_input"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "• Withdrawals are processed within 1 - 24 hours directly to your UPI.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    errorMessage?.let { err ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = err, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    RoyalButton(
                        text = if (isSubmitted) "WITHDRAWAL REQUEST SENT" else "SUBMIT WITHDRAWAL",
                        enabled = !isSubmitted,
                        onClick = {
                            val amt = withdrawAmount.toDoubleOrNull()
                            if (amt == null || amt < 200) {
                                errorMessage = "Minimum withdrawal amount is ₹200"
                            } else if ((user?.walletBalance ?: 0.0) < amt) {
                                errorMessage = "Insufficient balance in your wallet!"
                            } else if (upiId.isBlank() || !upiId.contains("@")) {
                                errorMessage = "Enter a valid UPI ID (e.g. name@upi)"
                            } else {
                                errorMessage = null
                                isSubmitted = true
                                viewModel.submitWithdrawal(
                                    amount = amt,
                                    upiId = upiId,
                                    holderName = user?.name ?: "User",
                                    onSuccess = {
                                        withdrawAmount = ""
                                        upiId = ""
                                        isSubmitted = false
                                        onNavigate("history")
                                    }
                                )
                            }
                        },
                        testTag = "submit_withdrawal_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
