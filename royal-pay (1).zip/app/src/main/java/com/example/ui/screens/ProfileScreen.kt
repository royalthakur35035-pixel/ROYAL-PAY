package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalButton
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalTextField
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit
) {
    val userState by viewModel.user.collectAsState()
    val user = userState

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(user?.name ?: "") }
    var editMobile by remember { mutableStateOf(user?.mobile ?: "") }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "MY PROFILE",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "profile", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // USER AVATAR & INFO CARD
            RoyalCard(borderGold = true) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .border(2.dp, GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.royal_pay_logo),
                            contentDescription = "User Avatar",
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val userId6 = remember(user?.uid) {
                        val uidHash = user?.uid?.hashCode()?.let { kotlin.math.abs(it) } ?: 849201
                        (uidHash % 900000) + 100000
                    }

                    Text(
                        text = user?.name ?: "Royal",
                        color = GoldPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = user?.email ?: "neha.singh@royalpay.com",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "USER ID: $userId6",
                            color = GoldPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = GoldPrimary.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "ROYAL MEMBER",
                            color = GoldPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // MENU OPTIONS CARD
            RoyalCard(borderGold = false) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    ProfileMenuRow(
                        title = "Edit Profile",
                        icon = Icons.Filled.Edit,
                        onClick = {
                            editName = user?.name ?: ""
                            editMobile = user?.mobile ?: ""
                            showEditProfileDialog = true
                        },
                        testTag = "profile_menu_edit"
                    )

                    HorizontalDivider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

                    ProfileMenuRow(
                        title = "Transaction History",
                        icon = Icons.Filled.History,
                        onClick = { onNavigate("history") },
                        testTag = "profile_menu_history"
                    )

                    HorizontalDivider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

                    ProfileMenuRow(
                        title = "Team & Referrals",
                        icon = Icons.Filled.Group,
                        onClick = { onNavigate("team") },
                        testTag = "profile_menu_team"
                    )

                    HorizontalDivider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

                    ProfileMenuRow(
                        title = "24/7 Customer Support",
                        icon = Icons.Filled.HeadsetMic,
                        onClick = { onNavigate("support") },
                        testTag = "profile_menu_support"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            RoyalButton(
                text = "LOGOUT ACCOUNT",
                onClick = {
                    viewModel.logout(onLoggedOut = onLogout)
                },
                icon = Icons.Filled.ExitToApp,
                testTag = "logout_button"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text(text = "Edit Profile Info", color = GoldPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    RoyalTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = "Full Name",
                        leadingIcon = Icons.Filled.Person
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showEditProfileDialog = false }
                ) {
                    Text(text = "Save Changes", color = GoldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text(text = "Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkBackground
        )
    }
}

@Composable
fun ProfileMenuRow(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Icon(
            imageVector = Icons.Filled.ChevronRight,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(20.dp)
        )
    }
}
