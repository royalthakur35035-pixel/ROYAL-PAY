package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TransactionRecord
import com.example.data.model.TransactionStatus
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalStatCard
import com.example.ui.theme.*

data class QuickActionItem(
    val label: String,
    val icon: ImageVector,
    val route: String,
    val isHighlighted: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val userState by viewModel.user.collectAsState()
    val transactionsState by viewModel.transactions.collectAsState()
    val user = userState

    val quickActions = listOf(
        QuickActionItem("Buy", Icons.Filled.ShoppingCart, "buy"),
        QuickActionItem("Sell", Icons.Filled.MonetizationOn, "sell"),
        QuickActionItem("Team", Icons.Filled.Group, "team"),
        QuickActionItem("History", Icons.Filled.Receipt, "history"),
        QuickActionItem("Support", Icons.Filled.SupportAgent, "support")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.royal_pay_logo),
                                contentDescription = "Royal Pay Logo",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        }
                        Column {
                            Text(
                                text = "Royal Pay",
                                style = TextStyle(
                                    brush = Brush.horizontalGradient(listOf(GoldPrimary, GoldLight)),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                )
                            )
                            Text(
                                text = "Verified Member",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(DarkSurface)
                            .border(1.dp, DarkBorder, CircleShape)
                            .clickable { onNavigate("notifications") }
                            .testTag("home_top_notifications"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    if (user?.isAdmin == true) {
                        Box(
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(DarkSurface)
                                .border(1.dp, DarkBorder, CircleShape)
                                .clickable { onNavigate("admin_panel") }
                                .testTag("home_top_admin"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = "Admin Panel",
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "home", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // WALLET CARD (SLEEK INTERFACE DESIGN)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF1A1A1A), Color(0xFF0D0D0D))
                            )
                        )
                        .border(
                            width = 1.dp,
                            color = GoldPrimary.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(28.dp)
                        )
                        .testTag("home_wallet_banner")
                ) {
                    // Top-Right Ambient Glow Effect
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 20.dp, y = (-20).dp)
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary.copy(alpha = 0.08f))
                    )

                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = "WALLET BALANCE",
                                    color = GoldPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.5.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "₹${String.format("%.2f", user?.walletBalance ?: 190.0)}",
                                    color = TextPrimary,
                                    fontSize = 30.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(GoldPrimary.copy(alpha = 0.1f))
                                    .border(1.dp, GoldPrimary.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "ACTIVE",
                                    color = GoldPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        HorizontalDivider(color = Color.White.copy(alpha = 0.05f))

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Today's Income",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "+₹${String.format("%.2f", user?.todaysIncome ?: 0.0)}",
                                    color = GreenAccent,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Total Withdrawal",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "₹${String.format("%.2f", user?.totalWithdrawal ?: 0.0)}",
                                    color = TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // 1ST ORDER LUCKY SPIN BANNER (PROMINENT LARGE HERO CARD)
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF2A2108), Color(0xFF141109), Color(0xFF1C1605))
                            )
                        )
                        .border(1.5.dp, GoldPrimary, RoundedCornerShape(24.dp))
                        .clickable { onNavigate("buy") }
                        .padding(20.dp)
                        .testTag("home_lucky_spin_banner")
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = GoldPrimary.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Stars,
                                        contentDescription = null,
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "EXCLUSIVE OFFER",
                                        color = GoldPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = GreenAccent.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "1ST ORDER SPECIAL 🎰",
                                    color = GreenAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🎰",
                                fontSize = 42.sp,
                                modifier = Modifier.padding(end = 12.dp)
                            )

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "1st Order Lucky Spin Wheel",
                                    color = GoldPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Spin & win up to ₹500 instant cash bonus credited directly to your wallet!",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onNavigate("buy") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldPrimary,
                                contentColor = DarkBackground
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Text(
                                text = "SPIN WHEEL & BUY NOW 🎰",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }

            // QUICK ACTIONS GRID (4 COLUMNS SLEEK INTERFACE)
            item {
                Spacer(modifier = Modifier.height(4.dp))
                quickActions.chunked(4).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { item ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onNavigate(item.route) }
                                    .testTag("action_${item.label.lowercase()}")
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            if (item.isHighlighted) GoldPrimary.copy(alpha = 0.1f) else DarkSurface
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (item.isHighlighted) GoldPrimary.copy(alpha = 0.3f) else DarkBorderLight,
                                            shape = RoundedCornerShape(20.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.label,
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.label,
                                    color = if (item.isHighlighted) GoldPrimary else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (item.isHighlighted) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            // REFERRAL EARNINGS STAT CARD
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(DarkSurface.copy(alpha = 0.6f))
                        .border(1.dp, DarkBorderLight, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(GoldPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Group,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Referral Earnings",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "₹${String.format("%.2f", user?.referralIncome ?: 0.0)}",
                                    color = TextPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Button(
                            onClick = { onNavigate("withdraw") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldPrimary,
                                contentColor = DarkBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("home_referral_withdraw_btn")
                        ) {
                            Text(
                                text = "Withdraw",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // ANNOUNCEMENT / PROMO BANNER & REWARDS
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // FAST WITHDRAWAL & BONUS HIGHLIGHT BANNER
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(GoldPrimary.copy(alpha = 0.15f), DarkSurface)
                                )
                            )
                            .border(1.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.FlashOn,
                                        contentDescription = "Fast Withdrawal",
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "FAST WITHDRAWAL & REWARDS",
                                        color = GoldPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = GreenAccent.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "⚡ Instant Payout",
                                        color = GreenAccent,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Reward items grid / rows
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CardGiftcard,
                                            contentDescription = null,
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(text = "Refer & Earn Reward", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    }
                                    Text(text = "₹200", color = GreenAccent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }

                                HorizontalDivider(color = DarkBorderLight)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = null,
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(text = "1st Order Complete Bonus", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    }
                                    Text(text = "₹260", color = GreenAccent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }

                                HorizontalDivider(color = DarkBorderLight)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Stars,
                                            contentDescription = null,
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(text = "5 Orders Complete Bonus", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    }
                                    Text(text = "₹1000", color = GreenAccent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // FINANCIAL OVERVIEW
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "FINANCIAL OVERVIEW",
                    color = GoldPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RoyalStatCard(
                            title = "Total Income",
                            amount = "₹${String.format("%.2f", user?.totalIncome ?: 0.0)}",
                            icon = Icons.Filled.MonetizationOn,
                            accentColor = GoldPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        RoyalStatCard(
                            title = "Total Deposit",
                            amount = "₹${String.format("%.2f", user?.totalDeposit ?: 0.0)}",
                            icon = Icons.Filled.AccountBalanceWallet,
                            accentColor = GoldVariant,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // RECENT TRANSACTIONS HEADER
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECENT TRANSACTIONS",
                        color = GoldPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "View All",
                        color = GoldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onNavigate("history") }
                            .testTag("home_view_all_history")
                    )
                }
            }

            if (transactionsState.isEmpty()) {
                item {
                    RoyalCard {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No recent transactions found",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            } else {
                items(transactionsState.take(3)) { txn ->
                    TransactionItemRow(txn = txn)
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

// Helper Extension for Left Border on Promo Banner
fun Modifier.drawBehindLeftBorder(color: Color, width: androidx.compose.ui.unit.Dp) = this.drawWithContent {
    drawContent()
    drawRect(
        color = color,
        topLeft = androidx.compose.ui.geometry.Offset(0f, 0f),
        size = androidx.compose.ui.geometry.Size(width.toPx(), size.height)
    )
}

@Composable
fun TransactionItemRow(txn: TransactionRecord) {
    RoyalCard(borderGold = false) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            when (txn.status) {
                                TransactionStatus.Approved -> GreenAccent.copy(alpha = 0.15f)
                                TransactionStatus.Pending -> GoldPrimary.copy(alpha = 0.15f)
                                TransactionStatus.Rejected -> RedAccent.copy(alpha = 0.15f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (txn.type) {
                            com.example.data.model.TransactionType.BUY -> Icons.Filled.ShoppingCart
                            com.example.data.model.TransactionType.SELL -> Icons.Filled.MonetizationOn
                            com.example.data.model.TransactionType.DEPOSIT -> Icons.Filled.ArrowUpward
                            com.example.data.model.TransactionType.WITHDRAWAL -> Icons.Filled.ArrowDownward
                        },
                        contentDescription = null,
                        tint = when (txn.status) {
                            TransactionStatus.Approved -> GreenAccent
                            TransactionStatus.Pending -> GoldPrimary
                            TransactionStatus.Rejected -> RedAccent
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "${txn.type.name} #${txn.id}",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${txn.date} • ${txn.time}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "₹${String.format("%.2f", txn.amount)}",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = txn.status.name,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = when (txn.status) {
                        TransactionStatus.Approved -> GreenAccent
                        TransactionStatus.Pending -> GoldPrimary
                        TransactionStatus.Rejected -> RedAccent
                    }
                )
            }
        }
    }
}

