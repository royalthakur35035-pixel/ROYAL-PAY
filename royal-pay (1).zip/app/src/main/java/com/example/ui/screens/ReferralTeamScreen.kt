package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TeamMember
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalStatCard
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.*

@Composable
fun ReferralTeamScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val userState by viewModel.user.collectAsState()
    val teamMembersState by viewModel.teamMembers.collectAsState()
    val user = userState
    val context = LocalContext.current

    var selectedLevelTab by remember { mutableStateOf(1) }
    var toastMessage by remember { mutableStateOf<String?>(null) }

    val refCode = user?.referralCode ?: "ROYAL789"
    val refLink = "https://royalpay.com/register?ref=$refCode"

    val levelMembers = remember(teamMembersState, selectedLevelTab) {
        teamMembersState.filter { it.level == selectedLevelTab }
    }

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "REFERRAL & TEAM",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "team", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                // REFERRAL BONUS HIGHLIGHT BANNER
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = GoldPrimary.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "🎁 REFER & EARN BONUS",
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Get ₹200 Cash Bonus per friend!",
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "+ Level commissions & ⚡ Fast Withdrawal",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = GreenAccent.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "₹200",
                                color = GreenAccent,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // REFERRAL CODE & LINK CARD
                RoyalCard(borderGold = true) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "YOUR UNIQUE REFERRAL CODE",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                            modifier = Modifier
                                .clickable {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Referral Code", refCode))
                                    toastMessage = "Referral code copied to clipboard!"
                                }
                                .testTag("copy_referral_code_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = refCode,
                                    color = GoldPrimary,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Icon(
                                    imageVector = Icons.Filled.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = refLink,
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(DarkSurfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Referral Link", refLink))
                                toastMessage = "Referral link copied!"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = androidx.compose.ui.graphics.Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("copy_link_button")
                        ) {
                            Icon(imageVector = Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "SHARE REFERRAL LINK", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // EARNINGS OVERVIEW
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RoyalStatCard(
                        title = "Referral Earnings",
                        amount = "₹${String.format("%.2f", user?.referralIncome ?: 0.0)}",
                        icon = Icons.Filled.Group,
                        accentColor = GoldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    RoyalStatCard(
                        title = "Team Members",
                        amount = "${teamMembersState.size}",
                        icon = Icons.Filled.Group,
                        accentColor = GreenAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // LEVEL INCOME BREAKDOWN (LEVEL 1, 2, 3)
            item {
                Text(
                    text = "TEAM LEVEL BREAKDOWN",
                    color = GoldPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        1 to "Level 1 (10%)",
                        2 to "Level 2 (5%)",
                        3 to "Level 3 (2%)"
                    ).forEach { (lvl, title) ->
                        val isSelected = selectedLevelTab == lvl
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) GoldPrimary else DarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedLevelTab = lvl }
                                .testTag("team_level_tab_$lvl")
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) androidx.compose.ui.graphics.Color.Black else GoldPrimary
                                )
                            }
                        }
                    }
                }
            }

            if (levelMembers.isEmpty()) {
                item {
                    RoyalCard {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No Level $selectedLevelTab team members registered yet.",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            } else {
                items(levelMembers) { member ->
                    TeamMemberRow(member = member)
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    toastMessage?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(2500)
            toastMessage = null
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Snackbar(
                containerColor = GoldPrimary,
                contentColor = androidx.compose.ui.graphics.Color.Black
            ) {
                Text(text = msg, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TeamMemberRow(member: TeamMember) {
    RoyalCard(borderGold = false) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(GoldPrimary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = member.name.take(1),
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = member.name,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${member.mobile} • Joined ${member.joinedDate}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Lvl ${member.level}",
                    color = GoldPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Deposit: ₹${member.totalDeposit.toInt()}",
                    color = GreenAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
