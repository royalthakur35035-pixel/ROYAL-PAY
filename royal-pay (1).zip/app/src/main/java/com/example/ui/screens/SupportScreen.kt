package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalButton
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalOutlinedButton
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAccent
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SupportScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    var showLiveChatDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "24/7 CUSTOMER SUPPORT",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "home", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(GoldPrimary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.HeadsetMic,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(50.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "WE ARE HERE TO HELP YOU",
                color = GoldPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Text(
                text = "Connect directly with our 24/7 support managers",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // SUPPORT CHANNELS CARD
            RoyalCard(borderGold = true) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "OFFICIAL SUPPORT CHANNELS",
                        color = GoldPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // LIVE CHAT BUTTON
                    RoyalButton(
                        text = "LIVE CHAT SUPPORT",
                        onClick = { showLiveChatDialog = true },
                        icon = Icons.Filled.Chat,
                        testTag = "support_live_chat_btn"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // TELEGRAM BUTTON
                    RoyalOutlinedButton(
                        text = "JOIN TELEGRAM CHANNEL",
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/royalthakurprofit"))
                                context.startActivity(intent)
                            } catch (e: Exception) {}
                        },
                        icon = Icons.Filled.Send,
                        testTag = "support_telegram_btn"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // WHATSAPP BUTTON
                    RoyalButton(
                        text = "WHATSAPP HELPLINE",
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/919876543210?text=Hello%20Royal%20Pay%20Support"))
                                context.startActivity(intent)
                            } catch (e: Exception) {}
                        },
                        icon = Icons.Filled.SupportAgent,
                        testTag = "support_whatsapp_btn"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showLiveChatDialog) {
        AlertDialog(
            onDismissRequest = { showLiveChatDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Filled.SupportAgent, contentDescription = null, tint = GoldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Live Support Agent", color = GoldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        text = "Agent Vikal (Senior Manager) is connected.",
                        color = GreenAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• All deposits are processed automatically within 5 minutes.\n• For UTR verification issues, please upload a clear payment screenshot in the Buy screen.",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showLiveChatDialog = false }) {
                    Text(text = "Close Chat", color = GoldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkBackground
        )
    }
}
