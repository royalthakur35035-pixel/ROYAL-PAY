package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.RoyalPayRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val repository = RoyalPayRepository()

    val user: StateFlow<User?> = repository.user
    val transactions: StateFlow<List<TransactionRecord>> = repository.transactions
    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
    val teamMembers: StateFlow<List<TeamMember>> = repository.teamMembers
    val allUsers: StateFlow<List<User>> = repository.allUsers
    val vipPlans = repository.vipPlans

    private val _uiEvent = MutableSharedFlow<String>()
    val uiEvent: SharedFlow<String> = _uiEvent

    fun clearHistory() {
        repository.clearHistory()
        viewModelScope.launch { _uiEvent.emit("Transaction history cleared!") }
    }

    fun login(email: String, pass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.login(email, pass, onSuccess = {
                viewModelScope.launch { _uiEvent.emit("Login successful!") }
                onSuccess()
            }, onError = { err ->
                viewModelScope.launch { _uiEvent.emit("Login failed: $err") }
            })
        }
    }

    fun register(
        name: String,
        mobile: String,
        email: String,
        pass: String,
        refCode: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.register(name, mobile, email, pass, refCode, onSuccess = {
                viewModelScope.launch { _uiEvent.emit("Account registered successfully!") }
                onSuccess()
            }, onError = { err ->
                viewModelScope.launch { _uiEvent.emit("Registration error: $err") }
            })
        }
    }

    fun logout(onLoggedOut: () -> Unit) {
        repository.logout()
        onLoggedOut()
    }

    fun submitBuyPayment(amount: Double, utr: String, screenshotUri: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.submitBuyPayment(amount, utr, screenshotUri, onSuccess = {
                viewModelScope.launch { _uiEvent.emit("Payment submitted successfully! Status: Pending Approval") }
                onSuccess()
            }, onError = { err ->
                viewModelScope.launch { _uiEvent.emit("Error: $err") }
            })
        }
    }

    fun submitSell(amount: Double, upiId: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.submitSell(amount, upiId, onSuccess = {
                viewModelScope.launch { _uiEvent.emit("Sell order submitted! Status: Pending") }
                onSuccess()
            }, onError = { err ->
                viewModelScope.launch { _uiEvent.emit("Error: $err") }
            })
        }
    }

    fun submitWithdrawal(amount: Double, upiId: String, holderName: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.submitWithdrawal(amount, upiId, holderName, onSuccess = {
                viewModelScope.launch { _uiEvent.emit("Withdrawal request submitted! Status: Pending Approval") }
                onSuccess()
            }, onError = { err ->
                viewModelScope.launch { _uiEvent.emit("Error: $err") }
            })
        }
    }

    fun buyVipPlan(plan: VipPlan, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.buyVipPlan(plan, onSuccess = {
                viewModelScope.launch { _uiEvent.emit("Activated ${plan.name} successfully!") }
                onSuccess()
            }, onError = { err ->
                viewModelScope.launch { _uiEvent.emit("Purchase failed: $err") }
            })
        }
    }

    // ADMIN ACTIONS
    fun approveTransaction(txnId: String) {
        repository.approveTransaction(txnId)
        viewModelScope.launch { _uiEvent.emit("Transaction approved successfully!") }
    }

    fun rejectTransaction(txnId: String) {
        repository.rejectTransaction(txnId)
        viewModelScope.launch { _uiEvent.emit("Transaction rejected.") }
    }

    fun toggleBlockUser(userId: String) {
        repository.toggleBlockUser(userId)
        viewModelScope.launch { _uiEvent.emit("User status updated.") }
    }

    fun updateWalletBalanceAdmin(userId: String, newBalance: Double) {
        repository.updateWalletBalanceAdmin(userId, newBalance)
        viewModelScope.launch { _uiEvent.emit("Wallet balance updated by Admin.") }
    }

    fun sendBroadcastNotification(title: String, message: String) {
        repository.sendBroadcastNotification(title, message)
        viewModelScope.launch { _uiEvent.emit("Broadcast notification sent!") }
    }

    fun claimLuckySpinReward(bonusAmount: Double) {
        repository.claimLuckySpinReward(bonusAmount)
        viewModelScope.launch { _uiEvent.emit("🎉 ₹${bonusAmount.toInt()} First Order Bonus added to your wallet!") }
    }

    fun claimDailyCheckIn(day: Int, amount: Double) {
        repository.claimDailyCheckIn(day, amount)
        viewModelScope.launch { _uiEvent.emit("🎉 ₹${amount.toInt()} Day $day Daily Check-in Bonus added to your wallet!") }
    }
}
