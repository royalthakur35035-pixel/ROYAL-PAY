package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VipPlan
import com.example.ui.MainViewModel
import com.example.ui.components.RoyalBottomBar
import com.example.ui.components.RoyalButton
import com.example.ui.components.RoyalCard
import com.example.ui.components.RoyalTopBar
import com.example.ui.theme.*

@Composable
fun VipPlansScreen(
    viewModel: MainViewModel,
    onNavigate: (String) -> Unit
) {
    val userState by viewModel.user.collectAsState()
    val user = userState
    val vipPlans = viewModel.vipPlans

    var selectedPlanToBuy by remember { mutableStateOf<VipPlan?>(null) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = "ROYAL VIP INVESTMENTS",
                showBack = false
            )
        },
        bottomBar = {
            RoyalBottomBar(currentRoute = "home", onNavigate = onNavigate)
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                RoyalCard(borderGold = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "CURRENT VIP LEVEL", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "VIP LEVEL ${user?.vipLevel ?: 1}",
                                color = GoldPrimary,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = CircleShape,
                            color = GoldPrimary.copy(alpha = 0.2f),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "SELECT VIP PLAN (VIP 1 - VIP 10)",
                    color = GoldPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            items(vipPlans) { plan ->
                VipPlanCard(
                    plan = plan,
                    isCurrentLevel = (user?.vipLevel ?: 1) >= plan.level,
                    onBuyClick = { selectedPlanToBuy = plan }
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    selectedPlanToBuy?.let { plan ->
        AlertDialog(
            onDismissRequest = { selectedPlanToBuy = null },
            title = {
                Text(text = "Confirm ${plan.name} Purchase", color = GoldPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    val totalReturn = if (plan.price == 500.0) 570.0 else (plan.price + (plan.dailyIncome * plan.validityDays))
                    Text(text = "Plan Price: ₹${plan.price.toInt()}", color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text(text = "Profit (7%): ₹${plan.dailyIncome.toInt()}", color = GreenAccent)
                    Text(text = "Total Return: ₹${totalReturn.toInt()}", color = GoldPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Are you sure you want to activate this VIP tier?", color = TextSecondary, fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val p = plan
                        selectedPlanToBuy = null
                        viewModel.buyVipPlan(p, onSuccess = {
                            snackbarMessage = "${p.name} activated successfully!"
                        })
                    }
                ) {
                    Text(text = "Confirm Buy", color = GoldPrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedPlanToBuy = null }) {
                    Text(text = "Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkBackground
        )
    }

    snackbarMessage?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(3000)
            snackbarMessage = null
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Snackbar(
                containerColor = GoldPrimary,
                contentColor = androidx.compose.ui.graphics.Color.Black
            ) {
                Text(text = msg, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun VipPlanCard(
    plan: VipPlan,
    isCurrentLevel: Boolean,
    onBuyClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (isCurrentLevel) GreenAccent else GoldPrimary.copy(alpha = 0.5f),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("vip_card_${plan.level}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${plan.level}",
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = plan.name,
                        color = GoldPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = DarkSurfaceVariant
                ) {
                    Text(
                        text = "${plan.validityDays} Days",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "Order Price", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = "₹${plan.price.toInt()}",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    val totalReturn = if (plan.price == 500.0) 570.0 else (plan.price + plan.dailyIncome)
                    Text(text = "Total Return (7%)", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = "₹${totalReturn.toInt()}",
                        color = GreenAccent,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            RoyalButton(
                text = if (isCurrentLevel) "ACTIVE TIER" else "BUY NOW - ₹${plan.price.toInt()}",
                onClick = onBuyClick,
                testTag = "buy_vip_${plan.level}_button"
            )
        }
    }
}
