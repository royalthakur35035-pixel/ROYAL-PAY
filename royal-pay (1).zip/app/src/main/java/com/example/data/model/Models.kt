package com.example.data.model

data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val mobile: String = "",
    val referralCode: String = "",
    val referredBy: String = "",
    val walletBalance: Double = 1000.0,
    val todaysIncome: Double = 120.0,
    val totalIncome: Double = 3450.0,
    val totalDeposit: Double = 2500.0,
    val totalWithdrawal: Double = 1000.0,
    val referralIncome: Double = 450.0,
    val vipLevel: Int = 1,
    val isBlocked: Boolean = false,
    val isAdmin: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

enum class TransactionType {
    BUY, SELL, DEPOSIT, WITHDRAWAL
}

enum class TransactionStatus {
    Pending, Approved, Rejected
}

data class TransactionRecord(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val userMobile: String = "",
    val type: TransactionType = TransactionType.DEPOSIT,
    val amount: Double = 0.0,
    val utr: String = "",
    val upiId: String = "",
    val accountHolderName: String = "",
    val screenshotUrl: String = "",
    val date: String = "",
    val time: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: TransactionStatus = TransactionStatus.Pending
)

data class VipPlan(
    val id: Int,
    val name: String,
    val price: Double,
    val dailyIncome: Double,
    val validityDays: Int,
    val level: Int
)

data class NotificationItem(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val date: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

data class TeamMember(
    val id: String,
    val name: String,
    val mobile: String,
    val level: Int,
    val totalDeposit: Double,
    val joinedDate: String
)
